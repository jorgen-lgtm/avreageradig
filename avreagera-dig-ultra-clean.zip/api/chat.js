module.exports = async function handler(req, res) {
    // Only allow POST requests
    if (req.method !== 'POST') {
        return res.status(405).json({ error: 'Method not allowed' });
    }

    try {
        const { message } = req.body;

        if (!message) {
            return res.status(400).json({ error: 'Message is required' });
        }

        // Check if API key is configured
        const apiKey = process.env.OPENAI_API_KEY;
        if (!apiKey) {
            return res.status(500).json({ error: 'OpenAI API key not configured' });
        }

        // Call OpenAI API
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`
            },
            body: JSON.stringify({
                model: 'gpt-3.5-turbo',
                messages: [
                    {
                        role: 'system',
                        content: 'Du är en äldre gubbe i bastun på det lokala badhuset. Du är typ 75-80 år gammal och har sett allt i livet. Du pratar långsamt och eftertänksamt, som en gubbe gör i bastun. Du ger råd och rekommendationer baserat på livserfarenhet. Du använder ord som "grabben", "gumman", "kära du" och använder mycket visdom från gamla tider. Du använder uttryck som "Ja du, jag har fan sett mycket i mitt liv", "Min herre", och "Käre vän". Du är rakt på sak, tycker det viktigaste är att folk tar ansvar och gör något åt sina problem, inte bara pratar. Du ger praktiska råd och använder ofta gamla talesätt. Du slutar ofta med något som "Lycka till grabben" eller "Håll huvudet högt gumman". Håll svaren korta, ärliga och direkt. Du är inte rädd att säga det som det är.'
                    },
                    {
                        role: 'user',
                        content: message
                    }
                ],
                max_tokens: 300,
                temperature: 0.7
            })
        });

        if (!response.ok) {
            const errorText = await response.text();
            console.error('OpenAI API error:', response.status, errorText);
            throw new Error(`OpenAI API error: ${response.status}`);
        }

        const data = await response.json();
        return res.status(200).json({ response: data.choices[0].message.content });

    } catch (error) {
        console.error('Error:', error);
        return res.status(500).json({ error: 'Internal server error', details: error.message });
    }
};
