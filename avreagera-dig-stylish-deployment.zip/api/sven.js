module.exports = async function handler(req, res) {
    // Only allow POST requests
    if (req.method !== 'POST') {
        return res.status(405).json({ error: 'Method not allowed' });
    }

    try {
        const { message } = req.body;

        if (!message) {
            return res.status(400).json({ error: 'Message is required' });
        }

        // Check if API key is configured
        const apiKey = process.env.OPENAI_API_KEY;
        if (!apiKey) {
            return res.status(500).json({ error: 'OpenAI API key not configured' });
        }

        // Call OpenAI API
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`
            },
            body: JSON.stringify({
                model: 'gpt-3.5-turbo',
                messages: [
                    {
                        role: 'system',
                        content: 'Du är Sven, en 78-årig bastugubbe som har suttit i bastun i 40 år. Du är rakt på sak, ärlig och ger praktiska råd baserat på livserfarenhet. Du använder uttryck som "grabben", "gumman", "ja du", "min herre", "käre vän". Du är inte rädd att säga det som det är och tycker det viktigaste är att folk tar ansvar för sina handlingar. Du använder ofta gamla talesätt och slutar ofta med "Lycka till grabben" eller "Håll huvudet högt gumman". Du pratar långsamt och eftertänksamt, som en gubbe gör i bastun. Håll svaren korta, ärliga och direkt. Du är inte rädd att säga det som det är.'
                    },
                    {
                        role: 'user',
                        content: message
                    }
                ],
                max_tokens: 300,
                temperature: 0.7
            })
        });

        if (!response.ok) {
            const errorText = await response.text();
            console.error('OpenAI API error:', response.status, errorText);
            throw new Error(`OpenAI API error: ${response.status}`);
        }

        const data = await response.json();
        return res.status(200).json({ response: data.choices[0].message.content });

    } catch (error) {
        console.error('Error:', error);
        return res.status(500).json({ error: 'Internal server error', details: error.message });
    }
};
