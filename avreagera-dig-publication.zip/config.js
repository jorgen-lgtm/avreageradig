// Configuration for Avreagera Dig app
const config = {
    // AI Configuration
    ai: {
        // Set to true to use OpenAI API, false for simulated responses
        useOpenAI: true,
        
        // OpenAI API Key (replace with your actual key)
        openaiApiKey: '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',
        
        // OpenAI Model to use
        model: 'gpt-3.5-turbo',
        
        // Maximum tokens for AI response
        maxTokens: 200,
        
        // Temperature for response creativity (0.0 to 1.0)
        temperature: 0.7
    },
    
    // App Configuration
    app: {
        // App name
        name: 'Avreagera Dig',
        
        // App description
        description: 'En säker plats att ventilera dina känslor och få stöd',
        
        // Maximum length for user input
        maxInputLength: 1000,
        
        // Maximum number of posts to store locally
        maxPosts: 100
    },
    
    // UI Configuration
    ui: {
        // Animation duration in milliseconds
        animationDuration: 300,
        
        // Auto-scroll to new posts
        autoScrollToNewPosts: true,
        
        // Show timestamps
        showTimestamps: true
    }
};

// Make config available globally
window.config = config;
