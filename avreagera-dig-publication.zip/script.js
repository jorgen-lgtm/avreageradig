// Global variables
let posts = JSON.parse(localStorage.getItem('avreageraPosts')) || [];
let isGeneratingAI = false;

// DOM elements
const emotionInput = document.getElementById('emotionInput');
const submitBtn = document.getElementById('submitBtn');
const aiResponseSection = document.getElementById('aiResponseSection');
const aiResponse = document.getElementById('aiResponse');
const shareBtn = document.getElementById('shareBtn');
const postsContainer = document.getElementById('postsContainer');
const loadingOverlay = document.getElementById('loadingOverlay');

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    renderPosts();
    setupEventListeners();
});

// Event listeners
function setupEventListeners() {
    submitBtn.addEventListener('click', handleSubmit);
    shareBtn.addEventListener('click', handleShare);
    emotionInput.addEventListener('input', validateInput);
}

// Validate input
function validateInput() {
    const content = emotionInput.value.trim();
    const hasContent = content.length > 0;
    const withinLimit = content.length <= config.app.maxInputLength;
    
    submitBtn.disabled = !hasContent || !withinLimit || isGeneratingAI;
    
    // Show character count
    updateCharacterCount(content.length);
}

// Update character count display
function updateCharacterCount(length) {
    let counter = document.getElementById('charCounter');
    if (!counter) {
        counter = document.createElement('div');
        counter.id = 'charCounter';
        counter.style.cssText = 'font-size: 0.9rem; color: #718096; margin-top: 5px; text-align: right;';
        emotionInput.parentNode.appendChild(counter);
    }
    
    const maxLength = config.app.maxInputLength;
    counter.textContent = `${length}/${maxLength} tecken`;
    
    if (length > maxLength) {
        counter.style.color = '#e53e3e';
    } else if (length > maxLength * 0.8) {
        counter.style.color = '#f6ad55';
    } else {
        counter.style.color = '#718096';
    }
}

// Handle form submission
async function handleSubmit() {
    const content = emotionInput.value.trim();
    if (!content || isGeneratingAI) return;

    isGeneratingAI = true;
    submitBtn.disabled = true;
    showLoading();

    try {
        const aiResponseText = await generateAIResponse(content);
        displayAIResponse(aiResponseText);
    } catch (error) {
        console.error('Error generating AI response:', error);
        alert('Ett fel uppstod när AI:n skulle generera ett svar. Försök igen.');
    } finally {
        isGeneratingAI = false;
        hideLoading();
        submitBtn.disabled = false;
    }
}

// Generate AI response
async function generateAIResponse(userInput) {
    try {
        // Check if OpenAI is configured and enabled
        if (config.ai.useOpenAI && config.ai.openaiApiKey && config.ai.openaiApiKey !== 'your-openai-api-key-here') {
            return await generateOpenAIResponse(userInput);
        }
        
        // Fallback to simulated response
        return await generateSimulatedResponse(userInput);
    } catch (error) {
        console.error('AI generation error:', error);
        return await generateSimulatedResponse(userInput);
    }
}

// Generate response using OpenAI API
async function generateOpenAIResponse(userInput) {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${config.ai.openaiApiKey}`
        },
        body: JSON.stringify({
            model: config.ai.model,
            messages: [
                {
                    role: 'system',
                    content: 'Du är en empatisk och stöttande AI-assistent som hjälper människor att hantera sina känslor. Ge korta, varma och uppmuntrande svar på svenska. Fokusera på att validera känslor och ge hopp.'
                },
                {
                    role: 'user',
                    content: userInput
                }
            ],
            max_tokens: config.ai.maxTokens,
            temperature: config.ai.temperature
        })
    });

    if (!response.ok) {
        throw new Error(`OpenAI API error: ${response.status}`);
    }

    const data = await response.json();
    return data.choices[0].message.content;
}

// Generate simulated response for demo
async function generateSimulatedResponse(userInput) {
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Analyze input for more contextual responses
    const input = userInput.toLowerCase();
    
    if (input.includes('ledsen') || input.includes('deprimerad') || input.includes('sorg')) {
        return "Jag förstår att du känner dig ledsen just nu. Det är helt okej att känna så här, och dina känslor är giltiga. Kom ihåg att även de mörkaste dagar går över, och du är inte ensam i detta.";
    }
    
    if (input.includes('arg') || input.includes('frustrerad') || input.includes('irriterad')) {
        return "Jag hör att du känner dig arg och frustrerad. Det är naturligt att känna så här när saker inte går som planerat. Det är okej att känna ilska - det visar att du bryr dig. Försök att andas djupt och ge dig själv tid att bearbeta känslorna.";
    }
    
    if (input.includes('rädd') || input.includes('oro') || input.includes('ångest')) {
        return "Det låter som att du känner dig rädd eller orolig. Ångest kan kännas överväldigande, men kom ihåg att du har hanterat svåra känslor tidigare. Du är starkare än du tror, och det finns människor som bryr sig om dig.";
    }
    
    if (input.includes('ensam') || input.includes('isolerad')) {
        return "Jag förstår att du känner dig ensam. Det kan vara en av de svåraste känslorna att hantera. Kom ihåg att du inte är ensam - det finns människor som bryr sig om dig, även om det inte alltid känns så. Du förtjänar kärlek och stöd.";
    }
    
    // Default supportive response
    const responses = [
        "Tack för att du delar med dig av dina känslor. Det kräver mod att vara öppen om hur man mår. Dina känslor är viktiga och giltiga, och du förtjänar allt stöd du kan få.",
        "Jag hör dig, och dina känslor är helt naturliga. Det är okej att känna sig överväldigad ibland. Kom ihåg att du är värdefull och att det finns hopp om bättre dagar.",
        "Det låter som att du går igenom en utmanande tid. Dina känslor är en del av dig, och det är viktigt att erkänna dem. Du förtjänar kärlek, stöd och förståelse.",
        "Jag förstår att du känner så här, och det är helt okej. Du är inte ensam i dina känslor, och det finns alltid hopp om förändring. Ta hand om dig själv och kom ihåg att du är starkare än du tror."
    ];
    
    return responses[Math.floor(Math.random() * responses.length)];
}

// Display AI response
function displayAIResponse(response) {
    aiResponse.textContent = response;
    aiResponseSection.style.display = 'block';
    aiResponseSection.scrollIntoView({ behavior: 'smooth' });
}

// Handle sharing to community board
function handleShare() {
    const userContent = emotionInput.value.trim();
    const aiContent = aiResponse.textContent;
    
    if (!userContent || !aiContent) return;

    const newPost = {
        id: Date.now(),
        userContent: userContent,
        aiResponse: aiContent,
        timestamp: new Date(),
        reactions: {
            heart: 0,
            hug: 0,
            support: 0,
            strength: 0
        }
    };

    posts.unshift(newPost);
    
    // Limit number of posts
    if (posts.length > config.app.maxPosts) {
        posts = posts.slice(0, config.app.maxPosts);
    }
    
    savePosts();
    renderPosts();
    
    // Clear form
    emotionInput.value = '';
    aiResponseSection.style.display = 'none';
    validateInput();
    
    // Scroll to new post if enabled
    if (config.ui.autoScrollToNewPosts) {
        setTimeout(() => {
            const newPostElement = document.querySelector(`[data-post-id="${newPost.id}"]`);
            if (newPostElement) {
                newPostElement.scrollIntoView({ behavior: 'smooth' });
            }
        }, 100);
    }
}

// Render posts
function renderPosts() {
    if (posts.length === 0) {
        postsContainer.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-heart"></i>
                <h3>Inga inlägg än</h3>
                <p>Börja med att dela dina känslor för att se dem här på anslagstavlan</p>
            </div>
        `;
        return;
    }

    postsContainer.innerHTML = posts.map(post => `
        <div class="post" data-post-id="${post.id}">
            <div class="post-header">
                ${config.ui.showTimestamps ? `<span class="post-time">${formatDate(post.timestamp)}</span>` : ''}
            </div>
            <div class="post-content">
                <strong>Användarens känslor:</strong><br>
                ${escapeHtml(post.userContent)}
            </div>
            <div class="ai-response-content">
                <strong>AI:s stöttande svar:</strong><br>
                ${escapeHtml(post.aiResponse)}
            </div>
            <div class="reactions">
                <button class="reaction-btn" onclick="addReaction(${post.id}, 'heart')" title="Hjärta - Kärlek och omtanke">
                    <i class="fas fa-heart"></i>
                    <span class="reaction-count">${post.reactions.heart}</span>
                </button>
                <button class="reaction-btn" onclick="addReaction(${post.id}, 'hug')" title="Kram - Tröst och stöd">
                    <i class="fas fa-hands"></i>
                    <span class="reaction-count">${post.reactions.hug}</span>
                </button>
                <button class="reaction-btn" onclick="addReaction(${post.id}, 'support')" title="Stöd - Uppmuntrande">
                    <i class="fas fa-thumbs-up"></i>
                    <span class="reaction-count">${post.reactions.support}</span>
                </button>
                <button class="reaction-btn" onclick="addReaction(${post.id}, 'strength')" title="Styrka - Mod och kraft">
                    <i class="fas fa-fist-raised"></i>
                    <span class="reaction-count">${post.reactions.strength}</span>
                </button>
            </div>
        </div>
    `).join('');
}

// Add reaction to post
function addReaction(postId, reactionType) {
    const post = posts.find(p => p.id === postId);
    if (post) {
        post.reactions[reactionType]++;
        savePosts();
        renderPosts();
    }
}

// Utility functions
function formatDate(date) {
    const now = new Date();
    const postDate = new Date(date);
    const diffInHours = Math.floor((now - postDate) / (1000 * 60 * 60));
    
    if (diffInHours < 1) {
        return 'Just nu';
    } else if (diffInHours < 24) {
        return `${diffInHours} timmar sedan`;
    } else {
        const diffInDays = Math.floor(diffInHours / 24);
        return `${diffInDays} dagar sedan`;
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function savePosts() {
    localStorage.setItem('avreageraPosts', JSON.stringify(posts));
}

function showLoading() {
    loadingOverlay.style.display = 'flex';
}

function hideLoading() {
    loadingOverlay.style.display = 'none';
}

// Initialize input validation
validateInput();
