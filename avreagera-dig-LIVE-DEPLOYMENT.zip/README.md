# Avreagera Dig - Känslomässig stödplattform

En webbapplikation där användare kan avreagera och ventilera sina känslor med AI-stöd och dela med gemenskapen på en anslagstavla.

## Funktioner

- **Känslomässig avreagering**: Användare kan skriva om sina känslor och få stöttande AI-svar
- **AI-stöd**: Intelligent analys och empatiska svar baserat på användarens känslor
- **Gemenskapens anslagstavla**: Dela inlägg med andra användare
- **Emoji-reaktioner**: Reagera på inlägg med hjärtan, kramar, stöd och styrka
- **Responsiv design**: Fungerar på alla enheter
- **Lokal lagring**: Data sparas lokalt i webbläsaren

## Teknisk implementation

### Filer
- `index.html` - Huvudstruktur för applikationen
- `styles.css` - Styling och responsiv design
- `script.js` - JavaScript-funktionalitet
- `config.js` - Konfigurationsinställningar

### AI-integration
Applikationen stöder två lägen:
1. **Simulerat läge** (standard): Använder fördefinierade empatiska svar
2. **OpenAI API**: Ansluter till OpenAI för dynamiska AI-svar

### Funktioner i detalj

#### Känslomässig analys
- Analyserar användarens text för olika känslotyper
- Ger kontextuella svar baserat på identifierade känslor
- Stöttande och empatiska svar på svenska

#### Anslagstavla
- Visar alla delade inlägg kronologiskt
- Användarens känslor och AI:s svar visas tillsammans
- Emoji-reaktioner för gemenskap
- Tidsstämplar för när inlägg skapades

#### Emoji-reaktioner
- ❤️ Hjärta - Kärlek och omtanke
- 🤗 Kram - Tröst och stöd
- 👍 Stöd - Uppmuntrande
- ✊ Styrka - Mod och kraft

## Installation och setup

### Lokal utveckling
1. Klona eller ladda ner filerna
2. Öppna `index.html` i en webbläsare
3. Applikationen fungerar direkt utan server

### WordPress-uppladdning
1. Zippa alla filer (index.html, styles.css, script.js, config.js)
2. Ladda upp till WordPress som en statisk sida
3. Konfigurera AI-inställningar i `config.js` om önskat

### AI-konfiguration
För att använda riktig AI (OpenAI):
1. Skaffa en OpenAI API-nyckel
2. Uppdatera `config.js`:
   ```javascript
   ai: {
       useOpenAI: true,
       openaiApiKey: 'din-api-nyckel-här'
   }
   ```

## Användning

1. **Skriv dina känslor**: Använd textfältet för att beskriva hur du mår
2. **Få AI-stöd**: Klicka "Få stöd från AI" för att få ett empatiskt svar
3. **Dela med gemenskapen**: Klicka "Dela på anslagstavlan" för att publicera
4. **Reagera på andra**: Använd emoji-knapparna för att stötta andra användare

## Säkerhet och integritet

- All data lagras lokalt i användarens webbläsare
- Ingen server-kommunikation (förutom valfri AI API)
- Anonym användning - inga personuppgifter samlas in
- Data kan raderas genom att rensa webbläsarens lokala lagring

## Anpassning

### Styling
Redigera `styles.css` för att ändra:
- Färger och teman
- Layout och spacing
- Responsiv design
- Animationer

### Funktioner
Redigera `script.js` för att lägga till:
- Nya emoji-reaktioner
- Ytterligare AI-funktioner
- Nya UI-element

### Konfiguration
Uppdatera `config.js` för att ändra:
- AI-inställningar
- App-beteende
- UI-preferenser

## Support

För frågor eller support, kontakta utvecklaren eller skapa en issue i projektet.

## Licens

Detta projekt är öppet källkod och fritt att använda och modifiera.
